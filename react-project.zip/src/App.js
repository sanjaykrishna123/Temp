import ToDo from "./components/SCREENS/ToDo"

function App() {
  return (
    <ToDo />
  );
}

export default App;