import React, {useState} from "react";
import '../../../src/App.css';
import trash from "../assets/delete.svg";
import plus from "../assets/plus.svg"
import revert from "../assets/revert.svg";
import tick from "../assets/tick-green.svg";

export default function ToDo(){
    const [tasks1, setTasks1] = useState([{text: "Buy 1kg Tomato", id: 1},{text: "Buy 2kg Onion", id: 2},{text: "Visit friend", id: 3},{text: "Clean House", id: 4}]);
    const [tasks2, setTasks2] = useState([{text: "Washing Clothes", id: 5}, {text: "Play Cricket", id: 6}, {text: "1km Walking", id: 7}, {text: "Do Homework", id: 8}]);
    const [number, setNumber] = useState(tasks1.length + tasks2.length + 1);
    const [input, setInput] = useState("");

    let Add = () =>{
        if(input){
            setNumber((prevNumber) => prevNumber + 1);
            setTasks1([...tasks1, {text: input, id: number}]);
            setInput("");
        }
    }

    let remove = (id) =>{
        let new_tasks = tasks1.filter((task) => task.id !== id);
        setTasks1(new_tasks);
        let new_tasks2 = tasks2.filter((task) => task.id !== id);
        setTasks2(new_tasks2);
    }

    let move = (id, text) =>{
        let new_tasks = tasks1.filter((task) => task.id !== id);
        setTasks1(new_tasks);
        setTasks2([...tasks2, {text: text, id: id}]);
    }

    let reverse = (id, text) =>{
        let new_tasks = tasks2.filter((task) => task.id !== id);
        setTasks2(new_tasks);
        setTasks1([...tasks1, {text: text, id: id}]);
    }

    return(
        <>
            <div className="App">
                <h1>Todo List</h1>
                <section className="available">
                    <h3>Things to be done</h3>
                    <ul>
                        {tasks1.map((task) =>{
                            return(
                                <>
                                    <li className="list">
                                        <div className="container">
                                            <div className="circle" onClick={() => move(task.id, task.text)}></div>
                                            <span className="list">{task.id}, {task.text}</span>
                                            <img alt="delete" className="delete" src={trash} onClick={() => remove(task.id)}/>
                                        </div>
                                    </li>
                                </>
                            );
                        })}
                    </ul>
                    <img src={plus} className="plus" alt="plus"/>
                    <input
                        placeholder="Type new task..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                    />
                    <button className="add" onClick={Add}>Add New</button>
                </section>
                <section className="completed">
                        <h3>Completed</h3>
                        <ul className="completed">
                            {tasks2.map((task) =>{
                                return(
                                    <>
                                        <li>
                                            <div className="container">
                                                <div className="circle2">
                                                    <img src={tick} className="tick" alt="tick"/>
                                                </div>
                                                <span className="color">{task.id}, {task.text}</span>
                                                <img alt="revert" src={revert} className="revert" onClick={() => reverse(task.id, task.text)}/>
                                                <img className="delete" src={trash} alt="delete2" onClick={() => remove(task.id)}/>
                                            </div>
                                        </li>
                                    </>
                                );
                            })}
                        </ul>
                </section>
            </div>
        </>
    );
}